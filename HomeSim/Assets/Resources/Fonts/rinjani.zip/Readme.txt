Hello,


Thank you for downloading my font.


This demo font is for PERSONAL USE ONLY!

link to purchase full version and commercial license, please visit my store : 

https://www.creativefabrica.com/designer/saber-studio/ref/235609

If you need an extended license or corporate license, please contact me at : saputra.nova91@gmail.com


Donate Paypal click here: https://www.paypal.me/saberstudio

I really appreciate your donations.


Thank You,

Saber Studio